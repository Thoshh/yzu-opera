var $dom = YAHOO.util.Dom;
var $selector = YAHOO.util.Selector;
var $event = YAHOO.util.Event;

YAHOO.util.Event.onDOMReady(function () {
    var ht = 0;
    var chgBox = function(e) {
        var target = $event.getTarget(e);
        var parent = $dom.getAncestorByTagName(target, 'div');
        var parent2 = $dom.getAncestorByTagName(parent, 'div');
        var bd = $dom.getNextSibling(parent2);
        if ($dom.hasClass(parent2, 'FBB')){
            $dom.removeClass(parent2, 'FBB');
            $dom.setStyle($dom.getFirstChild(parent), 'display', 'block');
            $dom.setStyle($dom.getLastChild(parent), 'display', 'none');
            
            $dom.setStyle($selector.query('.GAB,.FAB, .HAB', parent2), 'display', 'none');
            $dom.setStyle(bd, 'display', 'block');
            //YAHOO.util.Anim(bd, {height: {from:0,to:ht}}).animate();
        } else {
            $dom.addClass(parent2, 'FBB');
            $dom.setStyle($dom.getFirstChild(parent), 'display', 'none');
            $dom.setStyle($dom.getLastChild(parent), 'display', 'block');
            
            $dom.setStyle($selector.query('.GAB,.FAB, .HAB', parent2), 'display', 'block');
            $dom.setStyle(bd, 'display', 'none');
            
            /*ht = parseInt($dom.getStyle(bd, 'height'));
            var an = YAHOO.util.Anim(bd, {height: {from:ht,to:0}});
            alert({height: {from:ht,to:0}});
            an.animate();*/
        }
    };
    $event.on($selector.query("div.LR"), 'click', chgBox);
    
    //sidebar
    
});